package swigncomponents;

public interface ButtonListener {

    // X Y COORDINATES
    void click(int x, int y);
}
