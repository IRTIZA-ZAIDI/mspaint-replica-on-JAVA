package swigncomponents;

import java.awt.*;

public abstract class Shapes {
    public abstract void draw(Graphics g);
    public abstract int size();
}
