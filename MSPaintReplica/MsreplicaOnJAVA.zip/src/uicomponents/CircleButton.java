package uicomponents;

import swigncomponents.ButtonListener;

import java.awt.*;

public class CircleButton extends ShapeButton {


    public CircleButton(int x, int y, int width, int height, Image i_depressed, Image i_pressed, String shape_type) {
        super(x, y, width, height, i_depressed, i_pressed, shape_type);
    }

    @Override
    public void click(int x, int y) {

    }
}
