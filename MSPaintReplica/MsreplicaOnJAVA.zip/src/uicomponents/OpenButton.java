package uicomponents;

import swigncomponents.ButtonListener;
import swigncomponents.OpenWindow;

import java.awt.*;
import java.io.File;

public class OpenButton extends MyActive implements ButtonListener {
    public OpenButton(int x, int y, int width, int height, Image i_depressed, Image i_pressed) {
        super(x, y, width, height, i_depressed, i_pressed);
    }


    @Override
    public void click(int x, int y) {


    }

}
